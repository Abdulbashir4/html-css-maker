import { state } from './state.js';
import { bindSidebar } from './sidebar.js';
import { bindSelection } from './selection.js';
import { setPreviewMode } from './preview.js';
import { exportPureHTML } from './export.js';
import { bindStylePanel } from './style-panel.js';
import { formatHTML } from "./export.js";
import { getPureHTMLForView } from "./export.js";




/* =========================
   PAGE NAME REMEMBER
========================= */

const pageNameInput = document.getElementById("pageNameInput");

// load saved page name
const savedPage = localStorage.getItem("codgen_page_name");
if(savedPage){
  pageNameInput.value = savedPage;
}

// save when typing
pageNameInput.addEventListener("input",()=>{
  localStorage.setItem(
    "codgen_page_name",
    pageNameInput.value.trim()
  );
});



/* =========================
   PANEL LOADER
========================= */

function loadPanel(url, targetId, callback) {

  fetch(url)
    .then(r => r.text())
    .then(html => {
      document.getElementById(targetId).innerHTML = html;
      if (callback) callback();
    });

}



/* =========================
   TAB SWITCH
========================= */

function bindTabs() {

  const tabBlock = document.getElementById('tabBlock');
  const tabStyle = document.getElementById('tabStyle');

  const blockPanel = document.getElementById('blockPanel');
  const stylePanel = document.getElementById('stylePanel');

  tabBlock.onclick = () => {
    blockPanel.classList.remove('hidden');
    stylePanel.classList.add('hidden');
  };

  tabStyle.onclick = () => {
    stylePanel.classList.remove('hidden');
    blockPanel.classList.add('hidden');
  };

}



/* =========================
   BOOTSTRAP
========================= */

document.addEventListener('DOMContentLoaded', () => {

  state.canvas = document.getElementById('canvas');

  if (!state.canvas) return;

  loadPanel('panels/blocks.html','blockPanel',bindSidebar);
  loadPanel('panels/styles.html','stylePanel',bindStylePanel);

  bindSelection();
  bindTabs();

  btnMobile.onclick = () => setPreviewMode('mobile');
  btnDesktop.onclick = () => setPreviewMode('desktop');
  btnCode.onclick = exportPureHTML;

});



/* =========================
   PUBLISH PAGE
========================= */

document.getElementById("btnPublish")
  .addEventListener("click", () => {

    const pageName = pageNameInput.value.trim();
    if(!pageName){
      alert("Enter page name");
      return;
    }

    // 🔹 pure html for live page
    const cleanHTML = formatHTML(
      getPureHTMLForView()
    );

    // 🔹 builder html for edit later
    const builderHTML = state.canvas.innerHTML;

    fetch("save_page.php",{
      method:"POST",
      headers:{
        "Content-Type":"application/x-www-form-urlencoded"
      },
      body:
        "page=" + encodeURIComponent(pageName) +
        "&html=" + encodeURIComponent(cleanHTML) +
        "&json=" + encodeURIComponent(builderHTML)
    })
    .then(r=>r.text())
    .then(t=>{
      alert("Server says: " + t);
    });

});



/* =========================
   VIEW LIVE PAGE
========================= */

document.getElementById("btnViewLive")
  .addEventListener("click", ()=>{

    const page = pageNameInput.value.trim();
    if(!page){
      alert("Enter page name first");
      return;
    }

    window.open("pages/" + page + ".php","_blank");

});



/* =========================
   LOAD PAGE INTO BUILDER
========================= */

document.getElementById("btnLoadPage")
  .addEventListener("click", ()=>{

    const page = pageNameInput.value.trim();
    if(!page){
      alert("Enter page name");
      return;
    }

    fetch("load_page.php?page=" + page)
      .then(r=>r.text())
      .then(html=>{

        if(!html){
          alert("Page not found");
          return;
        }

        // put html back to canvas
        state.canvas.innerHTML = html;
bindSelection();          // 🔥 REBIND EVENTS
alert("Page loaded into builder!");

      });

});
